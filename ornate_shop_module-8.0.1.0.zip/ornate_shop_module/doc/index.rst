Ornate Shop Module with Collapsibe Product Categories and Product Multi-image
=============================================================================
- Ornate Shop Module is a specially desinged module which combine Collapsibe Product Categories and Product Multi-image in just one module along side with elegant homepage degign.
- Ornate Shop Module has also included the collapsible product categories in wesite shop section. It doesnot matter how many product categories you have you will get a nice collapsible look with all the parent an child categories.

Installation
============
- Install the theme normally like other modules.

Configuration
=============
- To enable the Collapsible Product Categories on website shop page having edit permission, click on Customize, and select "Product Categories" to use the feature.
- To add multiple images to a product, you need to add images to the Product Images tab in the Products section and it will be shown in a slider under the main product image in the website.